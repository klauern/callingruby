# greetings.rb

puts "Good morning, #{$who}."

$, = ","
$\ = "\n"
print "Hi", $people

print "Here\'re #{$people.size + 1} people in total."