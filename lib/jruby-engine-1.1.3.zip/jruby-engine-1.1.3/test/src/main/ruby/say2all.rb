#say2all.rb

def say_to_all
  $list.each {|name| puts "See you, #{name}"}
end
