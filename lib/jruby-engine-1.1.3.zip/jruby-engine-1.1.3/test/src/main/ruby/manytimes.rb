# 
# manytimes.rb
 
def many_times(max)
  for i in 0...max
    puts $message
  end
end
